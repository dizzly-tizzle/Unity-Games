using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundEffects : MonoBehaviour
{
    public AudioSource Sounds;
    public List<AudioClip> HitSounds;
    public AudioSource Music;
    public AudioClip BackgroundMusic;

    private void Start()
    {
        Music.clip = BackgroundMusic;
        Music.Play();
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Metal"))
        {
            Sounds.clip = HitSounds[0];
            Sounds.Play();
        }

        else if (collision.gameObject.CompareTag("Wood"))
        {
            Sounds.clip = HitSounds[1];
            Sounds.Play();
        }

        else if (collision.gameObject.CompareTag("Intercome"))
        {
            Sounds.clip = HitSounds[2];
            Sounds.Play();
        }
    }
    
}
